There's not much to add to readme, I explained most of my code in comments. 
Results is the solution file, backend is backend, index.html is to help view the results in browser console. :) 
I couldn't import the solution file to the backend file because Node doesn't recognize the logical assignment operator &&=.